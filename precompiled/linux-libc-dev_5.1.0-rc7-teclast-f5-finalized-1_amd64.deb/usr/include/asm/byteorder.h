/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_X86_BYTEORDER_H
#define _ASM_X86_BYTEORDER_H

#include <linux/byteorder/little_endian.h>

#endif /* _ASM_X86_BYTEORDER_H */
